<?php
  /// QQQQ OBSOLETE
//  if(isset($_COOKIE['nom'])) {
//    // utilisation de la date moins une heure
//    setcookie ("nom", "", time() - 3600, "/");
//    setcookie ("registered", "", time() - 3600, "/");
//    setcookie ("couleur", "", time() - 3600, "/");
//  }
//
//  session_start();
//  session_destroy();
//
//  $dest = (isset($_GET['request_uri'])) ? $_GET['request_uri'] : dirname($_SERVER['PHP_SELF']).'/'.'wk_liste.php';
//  header('Location: http://'.$_SERVER['HTTP_HOST'].$dest);
//  exit();

?>
