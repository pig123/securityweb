// I18N constants
//
//LANG: "base", ENCODING: UTF-8
//Author: Translator-Name, <email@example.com>
// FOR TRANSLATORS:
//
//   1. PLEASE PUT YOUR CONTACT INFO IN THE ABOVE LINE
//      (at least a valid email address)
//
//   2. PLEASE TRY TO USE UTF-8 FOR ENCODING;
//      (if this is not possible, please include a comment
//       that states what encoding is necessary.)

{
  "AsciiMath Formula Input": "AsciiMath Formeleditor",
  "Formula Editor": "Formeleditor",
  "Input":"Eingabe",
  "Preview":"Vorschau",
  "Based on ASCIIMathML by ": "Basiert auf ASCIIMathML von ",
  "For more information on AsciiMathML visit this page: ":"Für weitere Informationen besuchen Sie bitte diese Seite: ",
  "Attention: Editing the formula in the editor is not possible, please use this dialog!" : "Achtung, ändern der Formel im Editor ist nicht möglich. Bitte benutzen Sie diesen Dialog!"
}
