// LANG: "de", ENCODING: UTF-8 | ISO-8859-1
// Sponsored by http://www.schaffrath-neuemedien.de
// Author: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "The file you are uploading doesn't have the correct extension.": "Die hochgeladene Datei ist im falschen Format.",
  "The file you are uploading already exists.": "Eine Datei mit diesem Namen existiert schon.",
  "The file you are uploading is to big. The max Filesize is": "Die hochgeladene Datei ist zu groß. Die maximakle Dateigröße beträgt",
  "Images on the Server:": "Bilder auf dem Server:",
  "Please select a file to upload.": "Wählen Sie eine Datei zum hochladen aus.",
  "Upload file": "Datei hochladen",
  "Open file in new window": "Datei in neuen Fenster anzeigen",
  "Size": "Größe",
  "Width:": "Breite",
  "Height:": "Höhe"
};