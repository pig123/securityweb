// I18N constants
// LANG: "de", ENCODING: UTF-8
{
  "Paste as Plain Text": "unformatierten Text einfügen"
};
