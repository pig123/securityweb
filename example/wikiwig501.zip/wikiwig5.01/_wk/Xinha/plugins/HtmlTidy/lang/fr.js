// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "HTML Tidy": "HTML Tidy",
  "Auto-Tidy": "Tidy automatique",
  "Don't Tidy": "Tidy non utilisé",
  "Tidy failed.  Check your HTML for syntax errors.": "Tidy a échoué. Vérifiez votre HTML for des erreurs de syntaxe"
};