// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Default": "Défaut",
  "Undefined": "Non défini",
  "Choose stylesheet": "Choisir feuille de style"
};