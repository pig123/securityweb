// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Raimund Meyer xinha@ray-of-light.org
{
  "Decimal numbers": "Zahlen",
  "Lower roman numbers": "Römisch klein",
  "Upper roman numbers": "Römisch groß",
  "Lower latin letters": "Zeichen klein",
  "Upper latin letters": "Zeichen groß",
  "Lower greek letters": "Griechisch",
  "Choose list style type (for ordered lists)": "Wählen Sie einen Typ für die Nummerierung aus"
};
