// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Mihai Bazon, http://dynarch.com/mishoo
{
  "Decimal numbers": "Decimale nummers",
  "Lower roman numbers": "Romeinse nummers klein",
  "Upper roman numbers": "Romeinse nummers groot",
  "Lower latin letters": "Latijnse letters klein",
  "Upper latin letters": "Latijnse letters groot",
  "Lower greek letters": "Griekse letters",
  "Choose list style type (for ordered lists)": "Kies stijl type (voor ordered lists)"
};
