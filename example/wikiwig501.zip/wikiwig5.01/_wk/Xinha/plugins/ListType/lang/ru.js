﻿// I18N constants
// LANG: "ru", ENCODING: UTF-8
// Author: Andrei Blagorazumov, a@fnr.ru
{
  "Decimal numbers": "Десятичные числа",
  "Lower roman numbers": "Строчные романские числа",
  "Upper roman numbers": "Заглавные романские числа",
  "Lower latin letters": "Строчные латинские символы",
  "Upper latin letters": "Заглавные латинские символы",
  "Lower greek letters": "Строчные греческие символы",
  "Choose list style type (for ordered lists)": "Выберите стиль списков (для упорядоченных списков)"
};