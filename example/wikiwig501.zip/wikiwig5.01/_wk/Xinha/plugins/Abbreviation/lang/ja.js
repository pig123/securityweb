// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Abbreviation": "略語",
  "Expansion:": "展開される語:",
  "Delete": "削除"
};