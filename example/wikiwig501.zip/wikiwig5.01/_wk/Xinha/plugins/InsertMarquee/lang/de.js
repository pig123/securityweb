// I18N constants
// LANG: "de", ENCODING: UTF-8 | ISO-8859-1
// Author: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "Insert scrolling marquee": "Marquee einfügen",
  "Insert marquee": "Marquee einfügen",
  "Direction:": "Ausrichtung:",
  "Behavior:": "Bewegung:",
  "Text:": "Text:",
  "Background-Color:": "Hintergrundfarbe:",
  "Width:": "Breite:",
  "Height:": "Höhe:",
  "Speed Control": "Geschwindigkeitseinstellungen",
  "Cancel": "Abbrechen"
};
