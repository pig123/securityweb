// I18N for the FullPage plugin
// LANG: "de", ENCODING: UTF-8
// Author: Holger Hees, http://www.systemconcept.de
{
  "Alternate style-sheet:": "Alternativer Stylesheet:",
  "Background color:": "Hintergrundfarbe:",
  "Cancel": "Abbrechen",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "Dokumenteigenschaften",
  "Document title:": "Dokumenttitel:",
  "OK": "OK",
  "Primary style-sheet:": "Stylesheet:",
  "Text color:": "Textfarbe:",
  "Character set:": "Zeichensatz",
  "Description:": "Beschreibung",
  "Keywords:": "Schlüsselworte",
  "UTF-8 (recommended)": "UTF-8 (empfohlen)"
}
