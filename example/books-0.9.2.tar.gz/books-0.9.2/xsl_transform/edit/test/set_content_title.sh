#!/bin/bash

xml_file=../../../content/books/xml/linux_server_admin/en/basicservices/network/section-011/content.xml
new_title=test

xsltproc --stringparam title "$new_title" \
         ../set_content_title.xsl $xml_file

