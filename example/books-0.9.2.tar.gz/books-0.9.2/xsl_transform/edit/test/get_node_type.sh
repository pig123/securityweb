#!/bin/bash

xml_file=../../../content/books/xml/linux_server_admin/en/index.xml
node_path=./basicservices/network/
xsltproc --stringparam path $node_path ../get_node_type.xsl $xml_file
