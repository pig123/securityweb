#!/bin/bash

xml_file=../../../content/books/xml/linux_server_admin/en/index.xml
#node_id=network_1
node_id=network
xsltproc --stringparam id "$node_id" ../get_node_id.xsl $xml_file
