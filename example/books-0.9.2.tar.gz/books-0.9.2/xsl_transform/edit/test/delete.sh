#!/bin/bash

xml_file=../../../content/books/xml/linux_server_admin/en/index.xml
#node_path=./basicservices/email/
node_path=./basicservices/dns/
xsltproc --stringparam path $node_path ../delete.xsl $xml_file
