#!/bin/bash

xml_file=../../../content/books/xml/linux_server_admin/en/basicservices/network/section-011/content.xml
new_id=test

xsltproc --stringparam id "$new_id" \
         ../set_content_id.xsl $xml_file

