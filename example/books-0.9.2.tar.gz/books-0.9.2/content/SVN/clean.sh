#!/bin/bash

### go to this directory
cd $(dirname $0)

### delete
rm -rf my_docs/ repository/ svn_cfg.txt post-commit book_list
rm -rf ../downloads/xml_source/

