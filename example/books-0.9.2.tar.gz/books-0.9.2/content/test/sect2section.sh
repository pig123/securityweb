#!/bin/bash

xsltproc ../xsl_transform/explode/pre-process.xsl $1 |more
