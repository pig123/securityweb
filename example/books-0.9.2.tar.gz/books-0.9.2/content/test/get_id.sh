#!/bin/bash

xsltproc ../xsl_transform/explode/get_id.xsl $1
