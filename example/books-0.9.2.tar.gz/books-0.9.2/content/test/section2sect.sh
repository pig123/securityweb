#!/bin/bash

xsltproc ../xsl_transform/explode/section2sect.xsl $1 |more
