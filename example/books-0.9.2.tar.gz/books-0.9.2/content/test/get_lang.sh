#!/bin/bash

xsltproc ../xsl_transform/explode/get_lang.xsl $1
