#!/bin/bash
### add a new record to the users

### get the parameter
user_record="$1"

### append the given user_record to the file of the users
users=templates/admin/access_rights/users
echo "$user_record" >> $users
