#!/bin/bash
### get a list of all the users

users=templates/admin/access_rights/users
gawk -F: '{print $1;}' $users | sort -n
